F = 1_000_000.0   
c = 0.09         
N = 10            
y = 0.085         
C = F * c
print("=== BÁO CÁO ĐỊNH GIÁ TRÁI PHIẾU DOANH NGHIỆP ===")
print(f"Mệnh giá (F): {F:,.0f} VNĐ | Lãi suất coupon (c): {c*100:.1f}% | Lợi suất YTM (y): {y*100:.1f}%\n")
print(f"1. Số tiền lãi coupon trả hàng năm (C): {C:,.0f} VNĐ\n")
print("2. Chiết khấu dòng tiền lãi Coupon qua các năm:")
print(f"{'Kỳ (Năm)':<10} | {'Dòng tiền Coupon':<20} | {'Giá trị hiện tại (PV)'}")
print("-" * 55)
tong_pv_coupon = 0.0
for t in range(1, N + 1):
    pv_c = C / ((1 + y) ** t)
    tong_pv_coupon += pv_c
    print(f"{t:<10} | {C:>16,.0f} VNĐ | {pv_c:>18,.2f} VNĐ")
print("-" * 55)
print(f"-> Tổng giá trị hiện tại của lãi coupon: {tong_pv_coupon:,.2f} VNĐ\n")
pv_f = F / ((1 + y) ** N)
print(f"3. Giá trị hiện tại của nợ gốc năm thứ {N} (PV_F): {pv_f:,.2f} VNĐ\n")
gia_trai_phieu = tong_pv_coupon + pv_f
print(f"4. Giá lý thuyết chuẩn của trái phiếu (P0): {gia_trai_phieu:,.2f} VNĐ")
if gia_trai_phieu > F:
    danh_gia = "Cao hơn mệnh giá (Premium Bond)"
elif gia_trai_phieu == F:
    danh_gia = "Đúng mệnh giá (Par Bond)"
else:
    danh_gia = "Thấp hơn mệnh giá (Discount Bond)"
print(f"-> Nhận định: Trái phiếu đang được bán {danh_gia} (do Lãi suất coupon c > YTM y).")