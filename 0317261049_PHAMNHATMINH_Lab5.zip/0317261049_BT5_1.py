tuoi = 25
so_du = 0.0
tien_gui = 60_000_000.0  # 60 triệu VNĐ
lai_suat = 0.10          # 10%/năm
tang_tien_gui = 0.08     # 8%/năm
muc_tieu = 10_000_000_000.0  # 10 tỷ VNĐ

nam = 1

print("=== BÁO CÁO MÔ PHỎNG KẾ HOẠCH HƯU TRÍ TỰ ĐỘNG ===")
print(f"Mục tiêu tài sản: {muc_tieu:,.0f} VNĐ")
print(f"{'Năm':<5} | {'Tuổi':<5} | {'Tiền gửi mới':<18} | {'Tiền lãi phát sinh':<20} | {'Dư nợ/Tài sản cuối năm'}")
print("-" * 75)
while so_du < muc_tieu:
    tien_lai = so_du * lai_suat
    so_du = so_du + tien_lai + tien_gui
    print(f"{nam:<5} | {tuoi:<5} | {tien_gui:>14,.0f} VNĐ | {tien_lai:>16,.0f} VNĐ | {so_du:>18,.0f} VNĐ")
    if so_du < muc_tieu:
        tien_gui *= (1 + tang_tien_gui)
        tuoi += 1
        nam += 1

print("-" * 75)
print(f"KẾT LUẬN: Khách hàng sẽ đạt mục tiêu nghỉ hưu sau {nam} năm (lúc {tuoi} tuổi).")