V_goc = 20.0  
delta_ex_list = [-0.03, 0.00, 0.03]          
delta_ir_list = [-0.02, -0.01, 0.01, 0.02]   

print("=== MA TRẬN PHÂN TÍCH ĐỘ NHẠY GIÁ TRỊ DANH MỤC (TỶ VNĐ) ===")
print(f"Vốn danh mục ban đầu: {V_goc:.2f} Tỷ VNĐ\n")
header = f"{'Thay đổi Lãi suất (Dòng) \\ Tỷ giá (Cột)':<38} |"
for ex in delta_ex_list:
    header += f" {ex * 100:>+4.1f}%  |"
print(header)
print("-" * len(header))
for ir in delta_ir_list:
    row_str = f"Lãi suất: {ir * 100:>+4.1f}%{'':<23} |"
    for ex in delta_ex_list:
        v_moi = V_goc * (1 + 1.5 * ex - 2.0 * ir)
        row_str += f" {v_moi:>5.2f} Tỷ |"
        
    print(row_str)

print("-" * len(header))