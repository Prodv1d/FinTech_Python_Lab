"""
Bài 3: Trích xuất Dữ liệu Giao dịch Tài chính (Xử lý chuỗi, Ép kiểu & Điều kiện)
"""

def kiem_tra_giao_dich(ma_giao_dich: str) -> str:
    """
    Trích xuất số tiền từ mã giao dịch và kiểm tra hạn mức OTP.
    Ví dụ mã giao dịch: 'GD001-5000000-VND'
    """
    # Cắt chuỗi lấy phần số tiền và ép kiểu sang int
    cac_phat_sinh = ma_giao_dich.split("-")
    so_tien = int(cac_phat_sinh[1])
    
    if so_tien >= 5000000:
        return "Giao dịch cần xác thực OTP"
    else:
        return "Giao dịch thành công"


if __name__ == "__main__":
    ma_gd = "GD001-5000000-VND"
    thong_bao = kiem_tra_giao_dich(ma_gd)
    print(f"Mã GD: {ma_gd}")
    print(f"Thành công: {thong_bao}")
