"""
Bài 4: Tính Lãi suất Tiết kiệm (Biến & Toán tử số học)

Đoạn script khai báo các thông tin số tiền gốc, lãi suất năm và thời gian gửi
để tính toán tổng số tiền nhận được theo công thức lãi đơn:
tong_tien = so_tien_goc * (1 + lai_suat_nam * thoi_gian)
"""

def tinh_tong_tien_tiet_kiem(so_tien_goc: float, lai_suat_nam: float, thoi_gian: float) -> float:
    """
    Tính tổng số tiền nhận được sau thời gian gửi tiết kiệm theo lãi đơn.
    """
    so_tien_goc = float(so_tien_goc)
    lai_suat_nam = float(lai_suat_nam)
    thoi_gian = float(thoi_gian)
    
    tong_tien = so_tien_goc * (1 + lai_suat_nam * thoi_gian)
    return tong_tien


if __name__ == "__main__":
    so_tien_goc = 100000000.0  # 100 triệu
    lai_suat_nam = 0.06         # 6%/năm
    thoi_gian = 2.0             # 2 năm
    
    tong_tien = tinh_tong_tien_tiet_kiem(so_tien_goc, lai_suat_nam, thoi_gian)
    print(f"Số tiền gốc: {so_tien_goc:,.0f} VNĐ")
    print(f"Lãi suất năm: {lai_suat_nam * 100}%")
    print(f"Thời gian: {thoi_gian} năm")
    print(f"Tổng số tiền nhận được: {tong_tien:,.0f} VNĐ")
