"""
Bài 1: Phân loại Hạn mức Rủi ro Tín dụng (Cấu trúc rẽ nhánh)
"""

def phan_loai_khach_hang(diem_credit: int) -> str:
    """
    Phân loại hạng rủi ro dựa trên điểm tín dụng.
    
    Parameters:
        diem_credit (int): Điểm tín dụng từ 300 đến 850.
        
    Returns:
        str: Phân hạng rủi ro tương ứng.
    """
    if 750 <= diem_credit <= 850:
        return "Rủi ro Thấp - Duyệt tự động"
    elif 600 <= diem_credit < 750:
        return "Rủi ro Trung bình - Cần thẩm định"
    elif 300 <= diem_credit < 600:
        return "Rủi ro Cao - Từ chối cấp tín dụng"
    else:
        return "Điểm tín dụng không hợp lệ (phải từ 300 đến 850)"


if __name__ == "__main__":
    # Test thử hàm
    diem_test = 720
    ket_qua = phan_loai_khach_hang(diem_test)
    print(f"Điểm: {diem_test} -> {ket_qua}")
