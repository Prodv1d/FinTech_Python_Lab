"""
Bài 2: Chuẩn hóa Dữ liệu Khách hàng (Xử lý chuỗi)
"""

def chuan_hoa_ten_khach_hang(ten_khach_hang: str) -> str:
    """
    Loại bỏ khoảng trắng thừa hai đầu và chuẩn hóa định dạng tên dạng 'Nguyen Van A'.
    """
    return ten_khach_hang.strip().title()


if __name__ == "__main__":
    ten_goc = " nGuYen VAn A "
    ten_da_chuan_hoa = chuan_hoa_ten_khach_hang(ten_goc)
    print(f"Tên gốc: '{ten_goc}'")
    print(f"Tên chuẩn hóa: '{ten_da_chuan_hoa}'")
