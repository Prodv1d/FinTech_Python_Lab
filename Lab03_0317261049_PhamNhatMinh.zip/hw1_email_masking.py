email = input("Nhập địa chỉ email: ")
username, domain = email.split("@")
masked_username = username[0:3]
result = masked_username + "***@" + domain
print("Email sau khi bảo mật:", result)
