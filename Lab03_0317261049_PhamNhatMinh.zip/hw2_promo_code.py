full_name = input("Nhập họ và tên đầy đủ: ").strip().title()
birth_year = input("Nhập năm sinh: ").strip()
name_parts = full_name.split()
name = name_parts[-1] if name_parts else full_name
name_prefix = name[:3].upper()
promo_code = f"{name_prefix}-{birth_year}-VIP"
print("Mã ưu đãi tạo được:", promo_code)
