"""Bài 1: Hàm Niên kim Trả góp (EMI) - Lab 6."""

def calculate_emi(principal: float, annual_rate: float, months: int) -> tuple[float, float]:
    """Tính số tiền niên kim trả góp hàng tháng (EMI) và tổng lãi phát sinh.

    Hàm áp dụng công thức Niên kim chuẩn:
        EMI = P * [r * (1 + r)^n] / [(1 + r)^n - 1]
    trong đó r là lãi suất tháng (annual_rate / 12), n là số tháng.

    Args:
        principal (float): Số tiền vay gốc ban đầu (Đơn vị: VNĐ). Phải lớn hơn 0.
        annual_rate (float): Lãi suất năm dạng thập phân (VD: 0.12 tương đương 12%/năm).
        months (int): Thời hạn vay tính theo tháng (n > 0).

    Returns:
        tuple[float, float]: Bộ gồm 2 giá trị ngầm định:
            - emi (float): Số tiền phải trả đều đặn mỗi tháng (VNĐ).
            - total_interest (float): Tổng tiền lãi phải trả toàn chu kỳ (VNĐ).

    Raises:
        ValueError: Nếu principal <= 0 hoặc months <= 0 hoặc annual_rate < 0.
    """
    if principal <= 0 or months <= 0 or annual_rate < 0:
        raise ValueError("Số tiền vay và thời hạn phải lớn hơn 0, lãi suất không được âm.")

    # Lãi suất theo tháng
    monthly_rate = annual_rate / 12

    if monthly_rate == 0:
        emi = principal / months
        total_interest = 0.0
    else:
        # Áp dụng công thức EMI
        growth_factor = (1 + monthly_rate) ** months
        emi = principal * (monthly_rate * growth_factor) / (growth_factor - 1)
        total_interest = (emi * months) - principal

    return emi, total_interest


if __name__ == "__main__":
    # Test case đề bài: Vay 1 tỷ, lãi 12%/năm, kỳ hạn 12 tháng
    loan_amount = 1_000_000_000
    yearly_rate = 0.12
    tenure_months = 12

    # Sử dụng Unpacking để hứng tuple trả về
    monthly_emi, total_interest_paid = calculate_emi(loan_amount, yearly_rate, tenure_months)

    # In kết quả định dạng dấu phẩy hàng nghìn
    print(
        f"Trả mỗi tháng: {round(monthly_emi):,} VNĐ | "
        f"Tổng lãi phải trả: {round(total_interest_paid):,} VNĐ"
    )