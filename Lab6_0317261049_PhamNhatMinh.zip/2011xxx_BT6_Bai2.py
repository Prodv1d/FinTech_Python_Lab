"""Bài 2: Hàm chấm điểm tín dụng tự động (Credit Scoring) - Lab 6."""

def credit_score(
    income: float, 
    credit_history_years: float, 
    has_bad_debt: bool = False
) -> str:
    """Đánh giá và phân nhóm điểm tín dụng của khách hàng.

    Hàm áp dụng cây quyết định theo các tầng rủi ro: Nợ xấu -> Nguy cơ cao -> VIP -> Tiêu chuẩn.

    Args:
        income (float): Thu nhập hàng tháng của khách hàng (Đơn vị: VNĐ).
        credit_history_years (float): Số năm lịch sử tín dụng đã tích lũy.
        has_bad_debt (bool, optional): Cờ ghi nhận có nợ xấu hay không. Mặc định là False.

    Returns:
        str: Kết quả phân hạng tín dụng, bao gồm một trong các nhãn:
            - "Reject": Khách hàng có nợ xấu.
            - "High Risk": Thu nhập dưới 10,000,000 VNĐ hoặc lịch sử dưới 1 năm.
            - "VIP": Thu nhập từ 20,000,000 VNĐ trở lên và lịch sử từ 3 năm trở lên.
            - "Standard": Các trường hợp hợp lệ còn lại.
    """
    # 1. Kiểm tra nợ xấu trước tiên
    if has_bad_debt:
        return "Reject"

    # 2. Kiểm tra nhóm rủi ro cao
    if income < 10_000_000 or credit_history_years < 1:
        return "High Risk"

    # 3. Kiểm tra nhóm VIP
    if income >= 20_000_000 and credit_history_years >= 3:
        return "VIP"

    # 4. Nhóm khách hàng tiêu chuẩn
    return "Standard"


if __name__ == "__main__":
    # Kiểm thử các trường hợp logic nghiệp vụ
    test_cases = [
        {"income": 25_000_000, "years": 4, "bad_debt": True, "expected": "Reject"},
        {"income": 8_000_000, "years": 2, "bad_debt": False, "expected": "High Risk"},
        {"income": 15_000_000, "years": 0.5, "bad_debt": False, "expected": "High Risk"},
        {"income": 25_000_000, "years": 3.5, "bad_debt": False, "expected": "VIP"},
        {"income": 15_000_000, "years": 2, "bad_debt": False, "expected": "Standard"},
    ]

    for idx, case in enumerate(test_cases, 1):
        result = credit_score(case["income"], case["years"], case["bad_debt"])
        print(f"Test {idx}: Result='{result}' | Expected='{case['expected']}' -> {'PASS' if result == case['expected'] else 'FAIL'}")