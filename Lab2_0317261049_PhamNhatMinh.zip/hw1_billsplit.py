# hw1_billsplit.py

# Nhập thông tin đầu vào
X = float(input("Nhập tổng hóa đơn (X): "))
Y = float(input("Nhập phần trăm tip (Y %): "))
N = int(input("Nhập số người chia (N): "))

# Tính tổng số tiền bao gồm tiền tip
tong_tien = X * (1 + Y / 100)

# Tính số tiền mỗi người phải trả và làm tròn thành số nguyên
tien_moi_nguoi = round(tong_tien / N)

# Hiển thị kết quả
print(f"\n--- KẾT QUẢ ---")
print(f"Tổng hóa đơn sau tip: {round(tong_tien):,} VNĐ")
print(f"Số tiền thực tế mỗi người phải trả: {tien_moi_nguoi:,} VNĐ")