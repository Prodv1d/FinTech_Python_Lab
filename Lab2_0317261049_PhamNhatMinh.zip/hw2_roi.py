# hw2_roi.py

# Nhập thông tin đầu vào
initial_investment = float(input("Nhập tổng vốn đầu tư ban đầu (Initial Investment): "))
final_value = float(input("Nhập tổng giá trị bán ra (Final Value): "))

# Tính lợi nhuận ròng (Net Profit)
net_profit = final_value - initial_investment

# Tính tỷ lệ ROI (%)
roi = (net_profit / initial_investment) * 100

# Hiển thị kết quả
print(f"\n--- KẾT QUẢ ---")
print(f"Lợi nhuận ròng (Net Profit): {net_profit:,.2f} VNĐ")
print(f"Tỷ suất sinh lời (ROI): {roi:.2f}%")